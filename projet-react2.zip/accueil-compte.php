<!DOCTYPE html>
<html>

<head>
    <title>Colnet</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="main">
        <img src="logoO.jpg">
        <div class="option">
            <a href="ajout-groupe.php">
                <div class="groupe">Ajouter un groupe</div>
            </a>
            <a href="ajout-etudiant.php">
                <div class="groupe">Ajouter un étudiant</div>
            </a>
            <a href="afficher-donnee.php">
            <div class="groupe"> Afficher donnés </div>
            </a>
            <a href="analyse.php">
            <div class="groupe">Compiler donnée statistique</div>
            </a>
        </div>
    </div>
</body>

</html>