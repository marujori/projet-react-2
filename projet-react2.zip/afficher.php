
<!DOCTYPE html>
<html>
<head>
<title>Colnet</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="formulaire">
    <h1>Colnet O'sullivan</h1>
<img src="logoO.jpg">
<h2>Veuillez vous connecter</h2>


<form method="post" action="afficher.php" class="form">
        <div class="col-25">
            <label for="nom">Nom d'utilisateur :</label>
            </div>
            <div class="col-75">
            <input type="text" class="text" id="username" name="username" required>       
            </div>
        <div>
        <div class="col-25">
            <label for="mdp">Mot de passe :</label>
        </div><div class="col-75">
            <input type="text"  id="motDePasse" name="motDePasse" required >
        </div></div>
        <input type="submit" value="Se connecter" class="button">
        <a href="compte.php">  <input type="button" class="button" value="Créer un compte" a href="compte.php" ></a>        
</form>
<?php
//Connexion a la base de données
include "connexion.php";
//Affichage pour le filtre utilisateur
if(isset($_POST["username"])){
//Récupération des données
$nomU = ($_POST['username']);
//Préparation de la requete
$statementUser = $conn->prepare("SELECT username FROM utilisateur WHERE username = '$nomU'");
//Liaison des valeurs avec les marqueurs
$statementUser->execute();
$resultUser = $statementUser->fetchAll(PDO::FETCH_ASSOC);

 }
// affichage filtre mot de passe
if(isset($_POST["motDePasse"])){
//Récupération des données
$Mdp = ($_POST['motDePasse']);
//Préparation de la requete
$statementMdp = $conn->prepare("SELECT motDePasse FROM utilisateur WHERE motDePasse  = '$Mdp'");
//Liaison des valeurs avec les marqueurs
$statementMdp->execute();
$resultMdp = $statementMdp->fetchAll(PDO::FETCH_ASSOC);

if (($resultUser && $resultMdp) == true) {
    echo "Crédentiels valides, vous pouvez accéder à <a href='accueil-compte.php'> votre compte</a>";
} else {
    echo "Crédentiels invalides, vérifiez vos informations ou <a href='compte.php'> créez un compte </a>";

} 
 }
 
?>

<h5>© 2022 Collège O'Sullivan de Québec</h5>


</body>
</html>