<!DOCTYPE html>
<html>

<head>
    <title>Colnet</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="formulaire">
    <img src="logoO.jpg">
    <h2>Ajouter un Étudiant</h2>
    <?php
    include "connexion.php";
    //formulaire si remplit 
    if (isset($_POST["submit"])) {
        //Préparation des données
        $codePermanent = $_POST["codePermanent"];
        $nomComplet = $_POST["nomComplet"];
        $adresse = $_POST["adresse"];
        $telephone = $_POST["telephone"];
        $moyenne = $_POST["moyenne"];
        //préparation de la requete
        $insertionEtudiant= $conn->prepare(
            "INSERT INTO etudiant (codePermanent, nomComplet, adresse, telephone, moyenne)
        VALUES (:codePermanent, :nomComplet, :adresse, :telephone, :moyenne)"
        );
        //Liaison des valeurs avec les marqueurs
        $insertionEtudiant->bindParam(':codePermanent', $codePermanent);
        $insertionEtudiant->bindParam(':nomComplet', $nomComplet);
        $insertionEtudiant->bindParam(':adresse', $adresse);
        $insertionEtudiant->bindParam(':telephone', $telephone);
        $insertionEtudiant->bindParam(':moyenne', $moyenne);
        //Éxécution 
        $insertionEtudiant->execute();
    }
    ?>

    <form method="post" action="ajout-etudiant.php">
        <div class="col-25">
            <label for="codePermanent">Code permanent:</label></div>
            <div class="col-75">
            <input type="text" id="codePermanent" class="text" name="codePermanent" required>
        </div>
        <div class="col-25">
            <label for="nomComplet">Nom complet :</label></div>
            <div class="col-75">
            <input type="text" id="nomComplet" class="text" name="nomComplet" required>
        </div>
        <div class="col-25">
            <label for="adresse">adresse:</label></div>
            <div class="col-75">
            <input type="text" id="adresse" class="text" name="adresse" required>
        </div>
        <div class="col-25">
            <label for="telephone">email :</label></div>
            <div class="col-75">
            <input type="text" id="telephone" class="text" name="telephone" required>
        </div>
        <div class="col-25">
            <label for="moyenne">Moyenne:</label></div>
            <div class="col-75">
            <input type="text" id="moyenne" class="text" name="moyenne" required>
        </div>
        <?php
        $groupe = $conn->prepare(
            "SELECT code FROM groupe"
        );
        $groupe->execute();
        $codeGroupe = $groupe->fetchAll(PDO::FETCH_ASSOC);
        //var_dump($categories);
        echo "<div>
        <label for='groupe'>Groupe : </label>
        <select name='groupe' id='groupe' class='text'>
           <option>Sélectionnez un groupe</option>";
           for($i=0; $i<count($codeGroupe); $i++){
            echo "<option value=".$codeGroupe[$i]['code'].">".$codeGroupe[$i]['code']."</option>";
           }
        echo "</select>
        </div>";
        ?>
        <input type="submit" name="submit" value="ajouter" class="button">
        <?php
        if (isset($_POST["submit"])) {
        ?>
            <p><?php echo $_POST["nomComplet"]; ?>  à été ajouté avec succès! retournez à la page compte  <a href="accueil-compte.php">ici</a> </p>
        <?php } ?>
    </form>
    </div>
</body>

</html>