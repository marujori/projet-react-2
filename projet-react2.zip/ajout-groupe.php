<!DOCTYPE html>
<html>

<head>
    <title>Colnet</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="formulaire">
    <img src="logoO.jpg">
    <h2>Ajouter un Groupe</h2>
    <?php
    include "connexion.php";
    //formulaire si remplit 
    if (isset($_POST["submit"])) {
        //Préparation des données
        $code = $_POST["code"];
        $nom = $_POST["nom"];
        $type = $_POST["type"];
    
        //préparation de la requete
        $insertionGroupe= $conn->prepare(
            "INSERT INTO groupe (code, nom, type)
        VALUES (:code, :nom, :type)"
        );
        //Liaison des valeurs avec les marqueurs
        $insertionGroupe->bindParam(':code', $code);
        $insertionGroupe->bindParam(':nom', $nom);
        $insertionGroupe->bindParam(':type', $type);
        //Éxécution 
        $insertionGroupe->execute();
    }
    ?>

    <form method="post" action="ajout-groupe.php">
    <div class="col-25">

            <label for="code">Code du groupe:</label>
    </div>
    <div class="col-75">

            <input type="text" id="code" class="text" name="code" required>
        </div>
        <div class="col-25">

            <label for="nom">Nom du programme :</label>
        </div>
        <div class="col-75">

            <input type="text" id="nom" class="text" name="nom" required>
        </div>
        <label for='type'> Type : </label>
        <select name='type' id='type' class='text'>
            <option value="En ligne">En ligne</option>
            <option value="En classe">En classe</option>
            <option value="Hybride">Hybride</option>
        </select>
    
        <input type="submit" class="button" name="submit" value="ajouter">
        <?php
        if (isset($_POST["submit"])) {
        ?>
            <p><?php echo "le groupe  à été ajouté avec succès! retournez à la page compte"?><a href="accueil-compte.php">ici</a> </p>
        <?php } ?>
    </form>
    </div>
</body>

</html>