<!DOCTYPE html>
<html>
<head>
<title>Colnet</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="formulaire">
    <h1>Colnet O'sullivan</h1>
<img src="logoO.jpg">
<h2>Affichage des moyennes</h2>


<form method="post" action="afficher-donnee.php" class="form">
       
<?php
include "connexion.php";
        $groupe = $conn->prepare(
            "SELECT code FROM groupe"
        );
        $groupe->execute();
        $codeGroupe = $groupe->fetchAll(PDO::FETCH_ASSOC);
        //var_dump($categories);
        echo "<div>
        <label for='groupe'>Groupe : </label>
        <select name='groupe' id='groupe'>
           <option>Sélectionnez un groupe</option>";
           for($i=0; $i<count($codeGroupe); $i++){
               echo "<option>".$codeGroupe[$i]['code']."</option>";
           }
        echo "</select>
        </div>";?>    
        
       <div>
        <label for='moyenne'>moyenne : </label>
        <select name='moyenne' id='moyenne'>
           <option value='descen' name='descen'>Trié par descendant</option>
           <option value='ascen' name='ascen'>Trié par ascendant</option>
       </select>
        </div>
        <input type="submit" name="submit" value="trier" class="button">
                
</form>
<div class="table">
<table>
        <thead>
            <tr>
            <tr>
                <th>Code Permanent</th>
                <th>Nom</th>
                <th> Adresse</th>
                <th> Télèphone</th>
                <th> Moyenne</th>
                <th> Code Groupe</th>
            </tr>
            </tr>
        </thead>
        <tbody>
    <?php
    $moyenne="";
    $select="";
    if(isset($_POST["moyenne"]) && isset($_POST["groupe"])){
        $moyenne = ($_POST["moyenne"]); 
        $select = ($_POST["groupe"]);     
    }
    if($moyenne == 'ascen'){
    include "connexion.php";
    $getmoyenne = $conn->prepare(
        "SELECT codePermanent, nomComplet,adresse,telephone,moyenne,codeGroupe FROM etudiant
         where codegroupe= '$select' order by moyenne asc");
   $getmoyenne->execute();
   $resultat = $getmoyenne->fetchAll(PDO::FETCH_ASSOC);
   //var_dump($resultat);
   foreach($resultat as $ligne){?>
   <tr>
   <td><?php echo $ligne['codePermanent'];?></td>
    <td><?php echo $ligne['nomComplet'];?></td>
    <td><?php echo $ligne['adresse'];?></td>
    <td><?php echo $ligne['telephone'];?></td>
    <td><?php echo $ligne['moyenne'];?></td>
    <td><?php echo $ligne['codeGroupe'];?></td>
   </tr>
  <?php } ?><?php
}else if($moyenne == 'descen'){
    $getmoyenne = $conn->prepare(
        "SELECT codePermanent, nomComplet,adresse,telephone,moyenne,codeGroupe FROM etudiant
         where codegroupe= '$select' order by moyenne desc");   
         $getmoyenne->execute();
         $resultat = $getmoyenne->fetchAll(PDO::FETCH_ASSOC);
         //var_dump($resultat);
         foreach($resultat as $ligne){?>
         <tr>
            <td><?php echo $ligne['codePermanent'];?></td>
            <td><?php echo $ligne['nomComplet'];?></td>
            <td><?php echo $ligne['adresse'];?></td>
            <td><?php echo $ligne['telephone'];?></td>
            <td><?php echo $ligne['moyenne'];?></td>
            <td><?php echo $ligne['codeGroupe'];?></td>

         </tr>
        <?php }?>
<?php
}
?>

<h5>© 2022 Collège O'Sullivan de Québec</h5>


</body>
</html>