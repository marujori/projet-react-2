<!DOCTYPE html>
<html>
<head>
<title>Colnet</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<img src="logoO.jpg">
<h2>Veuillez vous créer un compte</h2>
<?php
include "connexion.php";
//formulaire si remplit 
if(isset($_POST["submit"])){
    //Préparation des données
    $nomComplet = $_POST["nomComplet"];
    $username = $_POST["username"];
    $codePostal = $_POST["codePostal"];
    $email = $_POST["email"];
    $motDePasse = $_POST["motDePasse"];
    //préparation de la requete
    $insertionAuto = $conn->prepare(
        "INSERT INTO utilisateur (nomComplet, username, codePostal, email, motDePasse)
        VALUES (:nomComplet, :username, :codePostal, :email, :motDePasse)"
    );
    //Liaison des valeurs avec les marqueurs
    $insertionAuto->bindParam(':nomComplet', $nomComplet);
    $insertionAuto->bindParam(':username', $username);
    $insertionAuto->bindParam(':codePostal', $codePostal);
    $insertionAuto->bindParam(':email', $email);
    $insertionAuto->bindParam(':motDePasse', $motDePasse);
    //Éxécution 
    $insertionAuto->execute();
}
?> 

<form method="post" action="compte.php">
        <div>
            <label for="nom">Nom complet:</label>
            <input type="text" id="nomComplet" name="nomComplet" required>
        </div>
        <div>
            <label for="mdp">Username :</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="mdp">Code postal :</label>
            <input type="text" id="codePostal" name="codePostal" required>
        </div>
        <div>
            <label for="mdp">email :</label>
            <input type="text" id="email" name="email" required>
        </div>
        <div>
            <label for="mdp">Mot de passe:</label>
            <input type="text" id="motDePasse" name="motDePasse" required>
        </div>
        <input type="submit" name="submit" value="S'enregistrer">
        <?php
if (isset($_POST["submit"])){

?>
<p><?php echo $_POST["nomComplet"]; ?> , votre compte à été créé avec succès! vous pouvez vous connecter <a href="accueil.php">connecter</a> </p>
<?php } ?>
</form>

</body>
</html>