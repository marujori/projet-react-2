<!DOCTYPE html>
<html>
<head>
<title>Colnet</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php 
include "afficher.php";
?>
</body>
</html>