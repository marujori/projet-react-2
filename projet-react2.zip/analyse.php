
<!DOCTYPE html>
<html>
<head>
<title>Colnet</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="formulaire">
    <h1>Colnet O'sullivan</h1>
<img src="logoO.jpg">

<form method="post" action="analyse.php" class="form">
       
<?php
include"connexion.php";
        $moyenneEtudiant = $conn->prepare(
            "SELECT count(moyenne) FROM etudiant where moyenne"
        );
        $moyenneEtudiant->execute();
        $etudiant = $moyenneEtudiant->fetch(PDO::FETCH_ASSOC);

// eleve ayant réussi
$moyenneEtudiantSucces = $conn->prepare(
    "SELECT count(moyenne) FROM etudiant where moyenne >=12"
);
$moyenneEtudiantSucces->execute();
$etudiant2 = $moyenneEtudiantSucces->fetch(PDO::FETCH_ASSOC);

// moyenne pour en ligne

$moyenneLigne = $conn->prepare(
    "SELECT COUNT(moyenne) / (SELECT COUNT(moyenne) FROM etudiant WHERE codeGroupe='WEBA21L') *100 FROM etudiant WHERE codeGroupe='WEBA21L' AND moyenne > 12 "
);
$moyenneLigne->execute();
$ligne = $moyenneLigne->fetch(PDO::FETCH_ASSOC);

// moyenne pour en classe
$moyenneClasse = $conn->prepare(
    "SELECT COUNT(moyenne) / (SELECT COUNT(moyenne) FROM etudiant WHERE codeGroupe='WEBA21C') *100 FROM etudiant WHERE codeGroupe='WEBA21C' AND moyenne > 12 "
);
$moyenneClasse->execute();
$classe = $moyenneClasse->fetch(PDO::FETCH_ASSOC);

// moyenne pour hybride
$moyenneHybride = $conn->prepare(
    "SELECT COUNT(moyenne) / (SELECT COUNT(moyenne) FROM etudiant WHERE codeGroupe='WEBA21H') *100 FROM etudiant WHERE codeGroupe='WEBA21H' AND moyenne > 12 "
);
$moyenneHybride->execute();
$hybride = $moyenneHybride->fetch(PDO::FETCH_ASSOC);



?>

<div>
<h2>Veuillez consulté les statistique</h2>
<p><?php echo implode($etudiant) ?> étudiants ont été évalués</p>
<p><?php echo implode($etudiant2)?> étudiants ont été évalués</p>
<p>Le taux de réussite des étudiants en ligne est de <?php echo implode($ligne)?>%.</p>
<p>Le taux de réussite des étudiants en classe est de <?php echo implode($classe)?>%.</p>
<p>Le taux de réussite des étudiants en hybride est de <?php echo implode($hybride)?>%.</p>

</div>



</body>
</html>